Crédits :

Script réalisé par DE SAINT LEGER Térence en classe de Tle 7 Hélios



Infos :

Bienvenu sur PYRAT - Edition Deluxe (v1.3.0).
L'objectif est de récupérer le plus de fromages avant l'autre souris.

La carte se présente sous une forme de liste de liste de string.

Chaque charactère représente un élément différent :
    " " = un espace vide
    "#" = un mur
    "$" = un fromage

La carte est générée procéduralement, elle est donc aléatoire.
Les textures utilisée sont également aléatoires, mais n'ont aucun impacte sur la carte.

Le fichier update_log.txt vous donnera toutes les informations sur les dernières mises à jour



Le IA :

Votre IA doit être contenu dans un fichier python nommé main.
Votre fichier doit contnir une fonction nommée main.
Celle-ci sera exécutée par le script principal.

Chaque IA reçoit (et doit obligatoirment accepter) :
    - le labyrinthe sous forme de liste de liste de string
    - sa position (en tuiles) sous forme de tuple
    - la position de son adversaire (en tuiles) sous forme de tuple

Elles doivent retourner l'un des 4 élément suivant :
    - "H" pour avancer vers le HAUT (si possible)
    - "B" pour avancer vers le BAS (si possible)
    - "D" pour avancer vers la DROITE (si possible)
    - "G" pour avancer vers la GAUCHE (si possible)

Tout autre output ne sera pas accepté.

Vos IA seront bridées et verront leur vitesse d'exécution divisée par 5000, soit une vitesse de 0.002% par rapport à la vitesse originale.
La vitesse maximale (pour des raisons de sécurité) est de 25 exécutions à la secondes, soit 40 ms d'intervale minimum entre chaque exécution.
Cela ne devrait pas vous gèner, même avec un script très rapide.

VOTRE IA NE DOIT PAS CRASHER !
Dans le cas échéant, elle cessera de fonctionner.



Fichiers équipe (le contenu de cette rubrique sera mis à jour au fil du temps) :

Mettez un nom de fichier en 1 seul mot, avec aucuns charactères spéciaux.
Définissez votre fichier main, puis un dossier "custom" dans lequel vous mettrez un sprite "souris.png".



Contrôles :

ESC -------> Quitter
ENTRER ----> Regénérer aléatoirement le labyrinthe (recharge également les IA)
ESPACE ----> Activer/Désactiver l'affichage HD (par défaut OFF)
RETOUR ----> Mettre en marche/pause les IA (par défaut MARCHE)
ASTERISK --> Activer/Désactiver les éléments visuels de débug ainsi que les logs dans le terminal (par défaut ON)



Conseilles pratiques :

Spyder c'est nul !
Pour désactiver l'une des IA, mettez sa ligne de lancement de processus en commentaire.
Les dossiers d'équipe doivent-être valides pour que le code puisse fonctionner.



Règlement du tournoi (en cour d'élaboration):

INTERDICTION D'IMPORTER DES LIBRAIRIES OU DES MODULE !
Seules exceptions sont les fichiers fait par vous même en python (.py) ou format textuel (.txt, .csv) ainsi que les modules "random" et "time".
Interdiction pûre et dure de saboter l'IA adverse en affectant sa vitesse ou son code source.
Interdiction d'essayer de modifier les valeurs du code principal (vous pouvez les modifiers localement, mais c'est tout).
LE PLAGIAT INTERNET C'EST EXCLUSION DE LA COMPETITION !
Gentleman rule : On ne hack pas le PC faisant tourner la compétition, merci.



Contribution et suggestions :

N'hésitez pas à contribuer au projet PYRAT !
Vous pouvez créer votre propre système de génération de carte.
Vous pouvez créer vos propres textures.
Envoyez-les moi si vous voulez que je les ajoutes.
Je prends également toutes les suggestions.



Réclamations et questions :

Vous n'êtes pas satisfait de l'une des règles définies ?
Vous haïssez profondément une carte ou jeu de texture ?
Une question sur le tournois et ses règles/fonctionnement ?
Contactez moi pour en parler.



BONNE CHANCE A TOUS !